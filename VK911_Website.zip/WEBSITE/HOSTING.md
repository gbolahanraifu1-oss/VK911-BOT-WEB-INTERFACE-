# Free Hosting Guide — VK911 XMD

## Website (Frontend)

### Vercel ✅ RECOMMENDED (100% free forever)
Best option. Auto-deploys from GitHub.

1. Push your `index.html` to a GitHub repo
2. Go to https://vercel.com → Sign up free
3. Click **Add New Project** → Import your GitHub repo
4. Deploy → Get a URL like `https://vk911-pair.vercel.app`
5. Done ✅

### Netlify (also free)
Same process — https://netlify.com
Drag and drop your `index.html` for instant deploy.

---

## Bot Backend (Node.js)

### Railway.app ✅ RECOMMENDED
- $5 free credit monthly — enough for a small bot
- Auto-deploys from GitHub
- Steps:
  1. Push bot code to GitHub
  2. Go to https://railway.app → New Project → Deploy from GitHub
  3. Set environment variables from your `.env`
  4. Bot gets a URL: `https://vk911bot-production.up.railway.app`
  5. Put that URL in your website's Server URL field

### Render.com (free tier)
- Free web service (sleeps after 15 min idle)
- Not ideal for a bot but works for light use
- https://render.com → New Web Service → Connect GitHub

### Koyeb (free tier)
- Doesn't sleep like Render
- https://koyeb.com → Free tier available

---

## Setup Steps

1. **Deploy website** → Vercel (copy `index.html`)
2. **Deploy bot** → Railway (push repo, set .env vars)
3. **Copy Railway URL** → paste into website Server URL field
4. **Test** → Enter your number on the website, get pairing code
5. **Share** the Vercel URL with customers

---

## Environment Variables on Railway

Set these in Railway dashboard → Variables:
```
BOT_NAME=VK911 XMD
OWNER_NUMBER=2347062301699
PREFIX=.
COMMAND_MODE=public
TELEGRAM_BOT_TOKEN=your_token_here
WEB_PORT=3000
NEWSLETTER_JID=120363424626346173@newsletter
```

Railway auto-assigns PORT for web services — make sure your bot listens on `process.env.PORT`.

---

> © VK911 TECH
