// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 💣 VK911 XMD  |  Web Pairing API
// Add to both v2 and PRO bots
// Website hits GET /pair?phone=234...
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
const http = require('http');
const url  = require('url');

const PORT = process.env.WEB_PORT || 3000;

// Track pending web pair requests
const _pending = new Map(); // phone → resolve fn

function startPairApi(startSessionFn) {
    const server = http.createServer(async (req, res) => {
        // CORS headers — allow the website to call this API
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
        res.setHeader('Content-Type', 'application/json');

        if (req.method === 'OPTIONS') {
            res.writeHead(204); res.end(); return;
        }

        const parsed = url.parse(req.url, true);
        const path   = parsed.pathname;

        // ── Health check ─────────────────────────────────────
        if (path === '/health' || path === '/') {
            res.writeHead(200);
            res.end(JSON.stringify({ status: 'ok', bot: 'VK911 XMD', uptime: process.uptime() }));
            return;
        }

        // ── Pairing endpoint ──────────────────────────────────
        if (path === '/pair') {
            const phone = (parsed.query.phone || '').replace(/[^0-9]/g, '');
            if (!phone || phone.length < 7 || phone.length > 15) {
                res.writeHead(400);
                res.end(JSON.stringify({ error: 'Invalid phone number. Use international format e.g. 2347062301699' }));
                return;
            }

            console.log(`[WebPair] Request for +${phone}`);

            // Timeout: 45 seconds to get a code
            const timeout = setTimeout(() => {
                if (_pending.has(phone)) {
                    const { reject } = _pending.get(phone);
                    _pending.delete(phone);
                    reject(new Error('Pairing timeout — bot took too long. Try again.'));
                }
            }, 45000);

            try {
                const code = await new Promise(async (resolve, reject) => {
                    _pending.set(phone, { resolve, reject });

                    try {
                        // Start session for this phone
                        const sock = await startSessionFn(phone, null);

                        // If already registered — request code directly
                        if (sock.authState?.creds?.registered === false) {
                            // Socket just created — requestPairingCode will fire shortly
                            // (handled in startSession's pairing flow)
                        } else if (sock) {
                            // Existing session — call requestPairingCode directly
                            let attempts = 0;
                            const tryCode = async () => {
                                attempts++;
                                try {
                                    const c = await sock.requestPairingCode(phone);
                                    const pending = _pending.get(phone);
                                    if (pending) { clearTimeout(timeout); _pending.delete(phone); pending.resolve(c); }
                                } catch (e) {
                                    if (attempts < 6) setTimeout(tryCode, 2500);
                                    else { clearTimeout(timeout); _pending.delete(phone); reject(e); }
                                }
                            };
                            setTimeout(tryCode, 3000);
                        }
                    } catch (e) {
                        clearTimeout(timeout);
                        _pending.delete(phone);
                        reject(e);
                    }
                });

                const formatted = code.match(/.{1,4}/g)?.join('-') || code;
                res.writeHead(200);
                res.end(JSON.stringify({ code: formatted, phone }));

            } catch (err) {
                res.writeHead(500);
                res.end(JSON.stringify({ error: err.message || 'Failed to generate pairing code' }));
            }
            return;
        }

        res.writeHead(404);
        res.end(JSON.stringify({ error: 'Not found' }));
    });

    server.listen(PORT, () => {
        console.log(`🌐 Web Pairing API running on port ${PORT}`);
        console.log(`   Visit: http://localhost:${PORT}/health`);
    });

    return { server, deliverCode };
}

// Called from bot's pairing flow to deliver the code to the waiting HTTP request
function deliverCode(phone, code) {
    const pending = _pending.get(phone);
    if (pending) {
        _pending.delete(pending);
        pending.resolve(code);
        return true;
    }
    return false;
}

module.exports = { startPairApi, deliverCode };
